package hc2021;

/*The city plan consists of one-way streets and intersections. Each street:
● is identied by a unique name,
● leads from one intersection to another,
● does not contain any intersections in between (if two streets need to cross
outside an intersection, a bridge or tunnel is used),
● has a xed amount of time L it takes a car to get from the beginning of the
street to the end. If it takes L seconds to drive through a street and a car
enters it at time T it will arrive at the end of the street precisely at T+L ,
independently of how many cars are on the street.*/

public class Street {
	
	int begin; // križanje na kojem počinje
    int end; // na kojem završava
    String name;
    boolean greenLight; // true ako je zeleno, false ako je crveno
    //int changeTime; // vrijeme za koliko se promijeni svjetlo
    // TREBA NAPRAVITI NEKI BOG ZA MIJENJANJE BOJE SVJETLA

    int l; // vrijeme za prolazak ulice
	
	public Street(int b, int e, String name, int l) {
        this.begin = b;
        this.end = e;
        this.name = name;
        this.l = l;
        this.greenLight = false;
	}
}
