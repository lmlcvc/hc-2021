package hc2021;

import java.util.ArrayList;

public class Car {
	
	ArrayList<Street> put = new ArrayList<Street>();
	int totalPath;
	
	/*
	 * put - sekvenca ulica kroz koje će ići
	 * ---> kroz svako raskršće ide samo jednom
	 * 
	 * Svaki auto kreće od kraja prve ulice na svom putu i:
	 * 1. opcija - svjetlo je zeleno i prolazi ga
	 * 2. opcija - svjetlo je crveno i on čeka zeleno
	 * 
	 * više auta na jednom raskršću: prvi ide onaj koji je prvi došao (RED)
	 * ne postoji vremenski delay prolaska kroz semafor (svi koji trebaju proć prolaze)
	 * 
	 * kad auto dođe na zadnju ulicu, tu je gotov i on nestaje
	 */
	
	public Car(ArrayList<Street> p) {
		this.put = p;
		this.totalPath = getTotalPath(this);
	}

	public  int getTotalPath(Car c){
		int sum = 0;

		for(Street s : c.put){
			sum += s.l;
		}

		return sum;
	}



}
