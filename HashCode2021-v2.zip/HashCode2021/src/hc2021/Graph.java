package hc2021;

import java.util.ArrayList;
import java.util.Map;

class Graph {
    private Map<Vertex, ArrayList<Vertex>> adjVertices;
    
    void addVertex(String label) {
        adjVertices.putIfAbsent(new Vertex(label), new ArrayList<>());
    }

    void removeVertex(String label) {
        Vertex v = new Vertex(label);
        adjVertices.values().stream().forEach(e -> e.remove(v));
        adjVertices.remove(new Vertex(label));
    }
    
    void addEdge(String label1, String label2) {
        Vertex v1 = new Vertex(label1);
        Vertex v2 = new Vertex(label2);
        adjVertices.get(v1).add(v2);
        adjVertices.get(v2).add(v1);
    }
    
    void removeEdge(String label1, String label2) {
        Vertex v1 = new Vertex(label1);
        Vertex v2 = new Vertex(label2);
        ArrayList<Vertex> eV1 = adjVertices.get(v1);
        ArrayList<Vertex> eV2 = adjVertices.get(v2);
        if (eV1 != null)
            eV1.remove(v2);
        if (eV2 != null)
            eV2.remove(v1);
    }
    
    // dobivanje susjeda danog čvora
    ArrayList<Vertex> getAdjVertices(String label) {
        return adjVertices.get(new Vertex(label));
    }
}