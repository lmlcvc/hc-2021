package hc2021;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

/*
 * 6 4 5 2 1000
2 0 rue-de-londres 1
0 1 rue-d-amsterdam 1
3 1 rue-d-athenes 1
2 3 rue-de-rome 2
1 2 rue-de-moscou 3
4 rue-de-londres rue-d-amsterdam rue-de-moscou rue-de-rome
3 rue-d-athenes rue-de-moscou rue-de-londres
 */


public class Main {

    private static BufferedWriter w;
    public static ArrayList<Street> streets = new ArrayList<Street>();
    public static ArrayList<Car> cars = new ArrayList<Car>();

	public static void main(String args[]){

        /*
        Each intersection: --- svaki čvor grafa
    ● has a unique integer ID (for example 0, 1, 2 ...),
    ● has at least one street that comes into it, and at least one street coming out
    of it.*/

        File a = new File("a.txt");
        File out = new File("out.txt");
            
        try {
            	FileReader fr = new FileReader(a.getPath());
            	BufferedReader r = new BufferedReader(fr);

            	FileWriter fw = new FileWriter(out, true);
            	w = new BufferedWriter(fw);
            	w.write("");
            
            
            	/*
            	 * sekunde simulacije
            	 * broj križanja
            	 * ulica
            	 * auta
            	 * broj bodova za auto
            	 */
            	
            	// 1. isčitavanje podataka o broju ulica i auta i ostalog
            	String line = r.readLine();
            	String[] split = line.split("\\s++");
            	int nums[] = {0,0,0,0,0};
            	int i = 0;
            	for(String s : split) {
            		nums[i] = Integer.parseInt(s);
            		i++;
            	}
            		
            	int numStreets = nums[2];
            	int numCars = nums[3];
            	
            	// u output stavljamo broj križanja
                w.append(split[1]);
                w.newLine();
                
                System.out.println(split[1]);
            		
            	// 2. čitanje numStreets linija o ulicama
                for(int j = 0; j < numStreets; j++) {
            		String linija = r.readLine();
            		// poč križanje, završno križanje, ime, l
            		
            		String[] rijeci = linija.split("\\s++");
            		int begin = Integer.parseInt(rijeci[0]);
            		int end = Integer.parseInt(rijeci[1]);
            		String name = new String(rijeci[2]);
            		int l = Integer.parseInt(rijeci[3]);
            		
            		Street s = new Street(begin, end, name, l);
            		streets.add(s);
            		
            	}

                // 3. čitanje numCars linija o autima
                for(int j = 0; j < numCars; j++) {
                	String linija = r.readLine();
                	
                	String[] rijeci = linija.split("\\s++");
                	ArrayList<Street> p = new ArrayList<Street>();
                	int streetsToPass = Integer.parseInt(rijeci[0]);
                	
                	
                	for(int k = 1; k < streetsToPass; k++) {
                		String tmp = rijeci[k];
                		for(Street s : streets) {
                			if(s.name.equals(tmp)) {
                				p.add(s);
                			}
                		}
                		
                		// Street s = new Street(rijeci[k]);
                		//p.add(s);
                	}
                	
                	Car c = new Car(p);
                	cars.add(c);
                }
                
                
                // upisivanje podataka za svako križanje
                for(int k = 0; k < nums[1]; k++){
                	String kk = Integer.toString(k);
                    w.append(kk);
                    w.newLine();
                    System.out.println(k);

                 // broj ulica
                    // treba provjeriti da li ulica počinje/završava zadanim križanjem
                    // ako da, ispisati ju:
                // ime svake ulice - trajanje zelenog u sekundama
                    
                    int bla = 0;
                    for(Street s : streets) {
                    	if(s.end == k) {
                			bla++;
                		}
                    }
                    System.out.println(bla);
                    String t = Integer.toString(bla);
                    w.append(t);
                    w.newLine();
                    
                    for(Street s : streets) {

                    	
                    	if(s.begin == k || s.end == k) {
                    		w.append(s.name + " " + s.l);
                    		w.newLine();
                    		System.out.println(s.name + " " + s.l);
                    	}
                    }
                }
                
                //w.append(line);
                //w.newLine();
                	// System.out.println(line);
            
                /*
            	r.close();
    			fr.close();
                w.close();
                fw.flush();
                fw.close();*/

        	} catch(IOException e){
        		System.out.println("Error!");
        		e.printStackTrace();
        }

    }
    

}